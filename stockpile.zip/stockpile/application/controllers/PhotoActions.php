<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PhotoActions extends CI_Controller{
	public function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('form_validation');
		$this->load->model('user');
	}

	public function photoDetails(){
		$data=array();
            $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
            $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
            $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
            $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
            $data['user'] = $this->user->getRows(array('contributorID'=>$this->session->userdata('userId')));
            $data['index'] = $this->session->userdata('userIndex');
            $data['userpics'] = $this->user->getPicturesByUser($data['index']+1);
            $data['clickedPic'] = $this->user->getClickedPicture();
            $this->load->view('pages/photoview.php', $data);
	}


}