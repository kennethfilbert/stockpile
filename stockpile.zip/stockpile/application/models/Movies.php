<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Movies extends CI_Model{

		
		public function get_movie(){
			$query = $this->db->query("SELECT * FROM movies");

			return $query->result_array();
		}
		public function get_movie_details($id){
			$this->db->select('*');
			$this->db->from('movies');
			$this->db->where('id', $id);
			return $this->db->get()->row_array();
		}

		public function insert_movie($title, $year, $director){
			$this->db->select('COUNT(*)');
			$this->db->from('movies');
			$movieData = $this->db->get()->row_array();

			$fileName = str_pad($movieData['COUNT(*)']+1, 3, '0', STR_PAD_LEFT).'.JPG';

			$newData = array(
				'title' => $title,
				'year' => $year,
				'director' => $director,
				'poster' => $fileName);

			$this->db->set($newData);
			$this->db->insert('movies');
		}

		public function edit_movie($id, $title, $year, $director){
			$updatedData = array(
				'title' => $title,
				'year' => $year,
				'director' => $director);
			$this->db->set($updatedData);
			$this->db->where('id', $id);
			$this->db->update('movies');

		}

		public function get_total_data(){
			$this->db->select('COUNT(*)');
			$this->db->from('movies');
			$totalData = $this->db->get()->row_array();

			return $totalData['COUNT(*)'];
	}



	}



?>