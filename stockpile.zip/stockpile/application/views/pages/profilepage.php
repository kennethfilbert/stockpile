<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<?php
		echo $js;
		echo $css;
	?>
    <nav class="navbar navbar-default" style="background: linear-gradient( #333 , #444);" >
    <div class="container-fluid">
            <div class="navbar-header" >
                <a class="navbar-brand" style="font-size: 35px" href="<?php echo base_url(); ?>">STOCKPILE</a>
            </div>
            <!-- div class="topnav">
  <input type="text" placeholder="Search..">
    </div> -->
    </div>
</nav>
</head>
<body>
<div class="container">
    <h2>User Account</h2>

    <h3>Welcome <?php echo $user[$index]['username']; ?>!</h3>
    <div class="account-info">
        <p><b>Name: </b><?php echo $user[$index]['username']; ?></p>
        <p><b>Email: </b><?php echo $user[$index]['email']; ?></p>
        <div class="card-images">
            <?php
    
                    foreach ($userpics as $key => $value) {
                        echo '<div class="card" style="float:left; margin:10px; border: 0;">';
                        echo '<img class="card-img-top" src="'.base_url().$value['photoPath'].'" alt="No Image Found" style="height:300px; width: auto;">';
                        echo '<div class="card-img-overlay h-100 d-flex flex-column justify-content-end">';
                            echo '<p class="card-text">';
                            //echo 'by'.$owner['c.username'].'</p>';
                       echo '</div>';
                    echo '</div>';
                }

            ?>

    </div>
</div>
</body>
</html>