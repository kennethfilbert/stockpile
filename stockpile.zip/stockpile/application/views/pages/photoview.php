<!DOCTYPE html>
<html>
<head>
	<title>Photo</title>
	<?php
		echo $js;
		echo $css;
	?>
    <nav class="navbar navbar-default" style="background: linear-gradient( #333 , #444);" >
    <div class="container-fluid">
            <div class="navbar-header" >
                <a class="navbar-brand" style="font-size: 35px" href="<?php echo base_url(); ?>">STOCKPILE</a>
            </div>
            <!-- div class="topnav">
  <input type="text" placeholder="Search..">
    </div> -->
    </div>
</nav>
</head>
<body>
<div class="container">
    <h2>Photo By <?php echo $clickedPic['username']; ?></h2>

    <div class="account-info">
        <div class="card-images">
            <?php
                        
                        echo '<div class="card" style="float:left; margin:10px; border: 0;">';
                        echo '<img class="card-img-top" src="'.base_url().$clickedPic['photoPath'].'" alt="No Image Found" style="height:300px; width: auto;">';
                        echo '<div class="card-img-overlay h-100 d-flex flex-column justify-content-end">';
                            echo '<p class="card-text">';
                            //echo 'by'.$owner['c.username'].'</p>';
                       echo '</div>';
                    echo '</div>';
                

            ?>

    </div>
    <h2>Description</h2>
    <?php echo $clickedPic['description'] ?>
</div>
</body>
</html>