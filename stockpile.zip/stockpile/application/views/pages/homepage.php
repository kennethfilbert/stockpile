<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Stockpile | Free Photo Stock Online</title>

<?php 
    echo $js;
    echo $css;
?>

<nav class="navbar navbar-default" style="background: linear-gradient( #333 , #444);" >
    <div class="container-fluid">
            <div class="navbar-header" >
                <a class="navbar-brand" style="font-size: 35px" href="#">STOCKPILE</a>
            </div>
            <!-- div class="topnav">
  <input type="text" placeholder="Search..">
    </div> -->
        <?php


        if(!$this->session->userdata('isUserLoggedIn')){
            //var_dump($_SESSION);
            echo '<li class="nav-link">';
                    echo '<a class="btn btn-outline-light btn-lg mx-3" href="'.base_url().'index.php/UserActions/login','">';
                            echo 'Sign In';
                    echo '</a>';
                    echo '<a class="btn btn-outline-light btn-lg m-0" href="'.base_url().'index.php/UserActions/registration','">';
                            echo 'Sign Up';
                    echo '</a>';

                    
                echo '</li>';
        }
        else{
            //var_dump($_SESSION);
            echo '<h3 class="title" style="color:blue; "> Welcome, '.$user[$index]['username']."</h3>";
            echo '<div class="dropdown">';
                echo '<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">';
                echo 'Account';
                echo '<span class="caret"></span></button>';
                echo '<ul class="dropdown-menu">';
                echo '<li><a href="'.base_url().'index.php/UserActions/account','">';
                echo "My Profile";
                echo '</a></li>';
                echo '<br>';
                 echo '<li><a href="'.base_url().'index.php/UserActions/logout','">';
                    echo 'Logout';
                    echo '</a></li>';
                echo '</ul>';
            echo '</div>';
           

        }
        ?>
    </div>
</nav>

</head>

<body>

<!--banner-->
<div id="bannerCarousel" class="hero-image carousel slide carousel-inner" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#bannerCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#bannerCarousel" data-slide-to="1"></li>
        <li data-target="#bannerCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="item active ">
          <img class="hero-image" src="assets/resources/loading.jpg" alt="hills">
        </div>

        <div class="item">
          <img class="hero-image" src="assets/resources/loading2.jpg" alt="lake">
        </div>

        <div class="item">
          <img class="hero-image" src="ny.jpg" alt="New York">
        </div>

        <a class="left carousel-control" href="#bannerCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#bannerCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
  </div>
  <div class="hero-text" style="color: white;">
    <h1  style="font-size:80px">Free HD Stock Photos</h1>
    <h3>Over Dozens of Free Photos</h3>
        <form class="example" action="/search.php" style="margin:auto;max-width:100%">
          <input type="text" placeholder="Search.." name="search2">
          <button type="submit" ><i class="fa fa-search"></i></button>
        </form>
  </div>

</div>
<div class="sticky-top">
    <h1 class="pt-5 pb-5" style="font-size:60px;color: black;text-align: center;">Categories</h1>
    <ul class="sticky-bottom navbar bg-dark navbar-dark ">
      <li><a href="#" class="btn nav-link">Nature</a></li>
      <li><a href="#" class="btn nav-link">Sports</a></li>
      <li><a href="#" class="btn nav-link">Landscape</a></li>
      <li><a href="#" class="btn nav-link">Architecture</a></li>
      <li><a href="#" class="btn nav-link">Animals</a></li>
      <li><a href="#" class="btn nav-link">Human Interest & Lifestyle</a></li>
      <li><a href="#" class="btn nav-link">Favorites</a></li>
    </ul>
</div>

<!--images-->

<div class="container-expand-md">
    <div class="row-expand-md-4">
    <?php
        
        foreach ($pics as $key => $value) {
            //var_dump($value['photoPath']);
             
            echo '<div class="card col-4" style="float:left; border: 0;">';
                echo '<img class="card-img-top" src="'.$value['photoPath'].'" alt="No Image Found" style="height:300px; width: auto;">';
                echo '<div class="card-img-overlay h-100 d-flex flex-column justify-content-end">';
                    echo '<p class="card-text">';
                    echo 'by '.$owner['username'].'</p>';
                    echo '<a href="'.base_url().'index.php/PhotoActions/photoDetails','">';
                        echo "Details";
                    echo '</a>';
                echo '</div>';
            echo '</div>';
        }

    ?>

    </div>
</div>
</body>
<?php
    echo $footer;

?>
</html>