<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<hr>
<footer class="footer">
    
        <p style="margin-top:0.5%">Stockpile - &copy;2018</p>
    
</footer> 