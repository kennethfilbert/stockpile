<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class UserActions extends CI_Controller{
	public function __construct(){
		parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->library('upload');
		$this->load->library('form_validation');
		$this->load->model('user');
        $this->load->model('emailmodel');
	}

    public function index(){
            $data=array();
            $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
            $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
            $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
            $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
            $data['navbar'] = $this->load->view('pages/navbar.php', NULL, TRUE);
            $data['pics'] = $this->user->getPictures();
            $data['id'] = $this->user->get_id();
            //$data['movie'] = $this->movies->get_movie();
            if($this->session->userdata('isUserLoggedIn')){
                
                $data['user'] = $this->user->getRows(array('contributorID'=>$this->session->userdata('userId')));
                $data['index'] = $this->session->userdata('userIndex');
                $data['owner'] = $this->user->getPictureOwner($data['id']);
                $this->load->view('pages/homepage.php', $data);
            }

            else{

                $data['owner'] = $this->user->getPictureOwner($data['id']);
                $this->load->view('pages/homepage.php', $data);
            }
        }

	public function account(){
		$data = array();
        $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
        $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
        $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
        $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
		if($this->session->userdata('isUserLoggedIn')){
			$data['user'] = $this->user->getRows(array('contributorID'=>$this->session->userdata('userId')));
            $data['index'] = $this->session->userdata('userIndex');
            $data['userpics'] = $this->user->getPicturesByUser($data['index']+1);
			$this->load->view('pages/profilepage.php', $data);
		}
		else{
			redirect(base_url());
		}
	}

    

	public function login(){
        $data = array();
        $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
        $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
        $data['pics'] = $this->user->getPictures();
        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        if($this->input->post('signIn')){
            $this->form_validation->set_rules('username', 'username', 'required');
            $this->form_validation->set_rules('password', 'password', 'required');
            if ($this->form_validation->run() == true) {
                $con['returnType'] = 'single';

                $con['conditions'] = array(
                    'username'=>$this->input->post('username'),
                    'password' => md5($this->input->post('password'))
                );

                $checkLogin = $this->user->getRows($con);
                if($checkLogin){
                    $index = $this->user->get_index($checkLogin['contributorID']);
                    $this->session->set_userdata('isUserLoggedIn',TRUE);
                    $this->session->set_userdata('userId',$checkLogin['contributorID']);
                    $this->session->set_userdata('userIndex',$index['contributorID']-1);
                    redirect(base_url());
                }else{
                    $data['error_msg'] = 'Wrong email or password, please try again.';
                }
            }
        }
        $this->load->view('pages/loginpage', $data);
    }
        

	public function registration(){
        $data = array();
        $userData = array();
        $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
        $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
        $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
        $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
        $data['pics'] = $this->user->getPictures();
        if($this->input->post('signUp')){
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');
            $this->form_validation->set_rules('password', 'password', 'required');
            $this->form_validation->set_rules('conf_password', 'confirm password', 'required|matches[password]');

            $userData = array(
                'username' => strip_tags($this->input->post('name')),
                'email' => strip_tags($this->input->post('email')),
                'password' => md5($this->input->post('password')),
                'verificationCode' => md5($this->input->post('email')),
                'verifiedStatus' => 'I'
                //'gender' => $this->input->post('gender'),
                //'phone' => strip_tags($this->input->post('phone'))
            );

            if($this->form_validation->run() == true){
                $insert = $this->user->insert($userData);
                if($insert){
                        $this->sendVerificationEmail($userData['email']);
                        $this->session->set_flashdata('success_msg', 'Your registration was successfully. Please login to your account.');
                        
                        redirect(base_url());
                        echo "<script>";
                        echo "alert('You are now verified!');";
                        echo " </script>";
                }
                else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        $data['user'] = $userData;
        //load the view
        $this->load->view('pages/registrationpage.php', $data);
    }

     public function logout(){
        $this->session->unset_userdata('isUserLoggedIn');
        $this->session->unset_userdata('userId');
        $this->session->sess_destroy();
        redirect(base_url(), 'refresh');
    }

    public function email_check($str){

        $con['returnType'] = 'count';
        $con['conditions'] = array('email'=>$str);
        $checkEmail = $this->user->getRows($con);
        if($checkEmail > 0){
            $this->form_validation->set_message('email_check', 'The given email already exists.');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function verify($verificationText=NULL){
        $data = array();
         $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
            $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
            $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
            $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);

        $noRecords = $this->user->verifyEmailAddress($verificationText);
        if($noRecords > 0){
            $error = array('success' => "Email Verified");
            echo "<script>";
                echo "alert('You are now verified!');";
                echo " </script>";
        }
        else{
            $error= array('error' => "Sorry unable to verify");
        }
        $data['errormsg'] = $error;
        redirect(base_url(),'refresh');
    }

    public function sendVerificationEmail($str){

            $con['returnType'] = 'single';

                $con['conditions'] = array(
                    'email'=>$str
                );

                $checkLogin = $this->user->getRows($con);

                if($checkLogin){
                    $this->session->set_userdata('userEmail', $checkLogin['email']);
                    $this->session->set_userdata('userCode', $checkLogin['verificationCode']);
                    //$this->session->set_userdata('userVerificationCode', $getCode['verificationCode']);
                }
            

        $this->emailmodel->sendVerificationEmail($this->session->userdata('userEmail'), $this->session->userdata('userCode'));
    }

    public function upload(){
        $data = array();
        $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
        $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
        $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
        $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
        $basePath = 'assets/resources/';
        
            if($this->input->post('submitPhoto')){
            $target_dir = "assets/resources/";
                $target_file = $target_dir . basename($_FILES["picture"]["name"]);
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                // Check if image file is a actual image or fake image
                
                    $check = getimagesize($_FILES["picture"]["tmp_name"]); // path of the temp file created by PHP during upload
                    if($check !== false) {
                        echo "File is an image - " . $check["mime"] . ".";
                        $uploadOk = 1;
                    } else {
                        echo "File is not an image.";
                        $uploadOk = 0;
                    }

                    if ($uploadOk == 0) {
                        $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    } 

                    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
                            $this->session->set_flashdata('error_msg', 'Sorry, only JPG, JPEG, & PNG files are allowed.');
                        
                            $uploadOk = 0;
                    }

                    else {
                        if (move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
                            echo "The file ". basename( $_FILES["picture"]["name"]). " has been uploaded.";
                        } else {
                            echo "Sorry, there was an error uploading your file.";
                        }
                    }
            
                
                $fileName =  $_FILES['picture']['name'];  
                //Prepare array of user data
                    $userData = array(
                        'title' => $this->input->post('title'),
                        'photoPath' => $basePath.$fileName,
                        'description' => $this->input->post('description'),
                        'category' => $this->input->post('category'),
                        'contributorID' => $this->session->userdata('userIndex')+1
                        //'picture' => $picture
                    );
            
            //Pass user data to model
                    $insertUserData = $this->user->insert_photos($userData);
                    
                    //Storing insertion status message.
                    if($insertUserData){
                        $this->session->set_flashdata('success_msg', 'Your photo has been added successfully.');
                    }else{
                        $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    }
                
            
        }
        //Form for adding user data
        $this->load->view('pages/upload.php', $data);
    }

    public function search(){
        $data=array();
            $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
            $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
            $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
            $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
            $data['navbar'] = $this->load->view('pages/navbar.php', NULL, TRUE); 
            
                $search_term = $this->input->post('searchBar');
                $data['result'] = $this->user->searcher($search_term); 

                if($data['result']){
                    $this->load->view('pages/searchresults.php', $data);
                }else{
                    $this->session->set_flashdata('error_msg', 'No results that match your search.');
                    $this->load->view('pages/searchresults.php', $data);
                } 
                
            
            
           
    }

    public function searchByCategory(){
        $data=array();
            $data['js'] = $this->load->view('include/script.php', NULL, TRUE);
            $data['css'] = $this->load->view('include/style.php', NULL, TRUE);
            $data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
            $data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
            $data['navbar'] = $this->load->view('pages/navbar.php', NULL, TRUE); 
            
                $search_term = $this->input->post('categoryBtn');
                $data['result'] = $this->user->categorySearcher($search_term); 

                if($data['result']){
                    $this->load->view('pages/searchresults.php', $data);
                }else{
                    $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
                    $this->load->view('pages/searchresults.php', $data);
                } 
                
            
            
           
    }



}