<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- home.php -->
<!DOCTYPE html>
<html>
<head>
<?php
        echo $js;
        echo $css;
    ?>
	<title>Week 12</title>
</head>
<body>
	<!-- main content here -->
    <div>
    <?php echo $header; ?>
        <h2 style="padding-left:16px;">Movie List <small>WebDB Cinemaks</small>
            <!-- cara href: base_url()/index.php/nama_controller/nama_method/param_jika_ada -->
            <a class="btn btn-primary pull-right" href="<?php echo base_url('index.php/MoviePage/insert') ?>">
                <i class="fa fa-fw fa-plus-circle"></i>Movie
            </a>
        </h2>
    </div>
    
    <div style="padding:0px 16px 0px 16px;">
    	<table id='tableMovie' class='table table-striped table-bordered' cellspacing='0' width='100%'>
            <thead>
                <tr>
                    <th></th>
                    <th>Title</th>
                    <th>Year</th>
                    <th>Director</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($movie as $key => $value) {
                    $index = $key+1;
                    $title = $value['title'];
                    $year = $value['year'];
                    $director = $value['director'];
                    $poster = $value['poster'];
                    echo "<tr>";
                    echo "<td name='index'>".$index."</td>";
                    echo "<td>".$title."</td>";
                    echo "<td>".$year."</td>";
                    echo "<td>".$director."</td>";
                    echo "<td>";
                    echo '<a class="btn btn-primary" name="btnDetail" href="'.base_url().'index.php/MoviePage/details/'.$value['id'].'">';
                            echo 'Detail';
                            echo '</a>';
                    echo '<a class="btn" name="btnEdit" href="'.base_url().'index.php/MoviePage/edit/'.$value['id'].'">';
                            echo 'Edit';
                            echo '</a>';          
                    echo "</tr>";

            }
        ?>
    		</tbody>
            <tfoot>
                <tr>
                    <th></th>
                    <th>Title</th>
                    <th>Year</th>
                    <th>Director</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
</body>
</html>
<script type="text/javascript">
    $('#tableMovie').DataTable();
</script>