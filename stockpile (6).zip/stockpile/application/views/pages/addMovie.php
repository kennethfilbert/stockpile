<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- home.php -->
<!DOCTYPE html>
<html>
<head>
	<title>Week 12</title>
  <?php
        echo $js;
        echo $css;
  ?>
</head>
<body>
	<!-- main content here -->
    <?php echo $navbar; ?>
    <div>
        <h2 style="padding-left:16px;">Add Movie <small>WebDB Cinemaks</small></h2>
    </div>
    
    <div class="container" style="padding:0px 16px 0px 16px;">
    	<form class="form-horizontal" role="form" action="<?php echo base_url().'index.php/AddMovie/addDatabase';?>" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <div class="col-sm-2">
              <label class="control-label">Title</label>
            </div>
            <div class="col-sm-6">
              <input type="text" class="form-control" name="title" placeholder="Title">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-2">
              <label class="control-label ">Year</label>
            </div>
            <div class="col-sm-4">
              <input type="number" class="form-control" name="year" placeholder="Year">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-2">
              <label class="control-label ">Director</label>
            </div>
            <div class="col-sm-6">
              <input type="text" class="form-control" name="director" placeholder="Director">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-2">
              <label class="control-label">Poster</label>
            </div>
            <div class="col-sm-6">
              <input type="file" class="form-control" name="poster">
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submitBtn" class="btn btn-primary">Submit</button>
              <a type="submit" name="cancelBtn" class="btn btn-default"  href="<?php echo base_url(); ?>">Cancel</a>
            </div>
          </div>
        </form>
    </div>
</body>
<script type="text/javascript">
    $('#tableMovie').DataTable();
</script>
</html>


