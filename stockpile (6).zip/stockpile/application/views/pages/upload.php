<!DOCTYPE html>
<html>  
<head>

    <title>Upload Picture</title>
    <?php
      echo $js;
      echo $css;
    ?>
    
    <nav class="navbar navbar-default" style="background: linear-gradient( #333 , #444);" >
    <div class="container-fluid">
            <div class="navbar-header" >
                <a class="navbar-brand" style="font-size: 35px" href="<?php echo base_url(); ?>">STOCKPILE</a>
            </div>
            <!-- div class="topnav">
  <input type="text" placeholder="Search..">
    </div> -->
    </div>
</nav>
</head>
<body>
<h2 style="text-align: center; margin-top: 5%;">Upload Photo</h2>
<div class="container" style="margin-top: 2%;">

<?php echo $this->session->flashdata('success_msg'); ?>
<?php echo $this->session->flashdata('error_msg'); ?>

<form role="form" method="post" enctype="multipart/form-data" action="">
    <div class="panel">
        <div class="panel-body">
            <div class="form-group">
                <label>Picture</label>
                <input class="form-control" type="file" name="picture" />
            </div>
            <div class="form-group">
                <label>Title</label>
                <input class="form-control" type="text" name="title" />
            </div>
            <div class="form-group">
                <label>Description</label>
                <input class="form-control" type="text" name="description" />
            </div>
            <div class="form-group">
            <label for="category">Category</label>
              <select class="form-control" id="category" name="category">
                <option>Architecture</option>
                <option>Human Interest & Lifestyle</option>
                <option>Landscape</option>
                <option>Animal</option>
                <option>Nature</option>
                <option>Sports</option>
              </select>
            </div>
             <div class="form-group">
                <input type="submit" class="btn btn-warning" name="submitPhoto" value="Upload Photo">
            </div>
        </div>
    </div>
</form>
    
    <!-- <form action="" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Name" required="" value="<?php echo !empty($user['username'])?$user['username']:''; ?>">
          <?php echo form_error('name','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email" required="" value="<?php echo !empty($user['email'])?$user['email']:''; ?>">
          <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="conf_password" placeholder="Confirm password" required="">
          <?php echo form_error('conf_password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="submit" name="signUp" class="btn-primary" value="Submit"/>
        </div>
    </form>
    <p class="footInfo">Already have an account? <a href="<?php echo base_url(); ?>index.php/UserActions/login">Login here</a></p> -->              
</div>
</body>
</html>