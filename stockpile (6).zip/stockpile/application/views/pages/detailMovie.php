<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- home.php -->
<!DOCTYPE html>
<html>
<head>
<?php
        echo $js;
        echo $css;
    ?>
	<title>Week 12</title>
</head>
<body>
	<!-- main content here -->
  <?php echo $header; ?>
    <div>
        <h2 style="padding-left:16px;"><?php echo $detailMovie['title']; ?><small>Movie Details</small>
        <a class="btn btn-primary pull-right" href="<?php echo base_url(); ?>">
          <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> Back
        </a>
        </h2>
    </div>
    <hr>
    <div style="padding:0px 16px 16px 16px;" class="col-sm-12">
      <div class="form-group">
        <div class="col-sm-3">
          <label class="control-label col-sm-12">Released: <?php echo $detailMovie['year']; ?></label>
          <label class="control-label col-sm-12">Director: <?php echo $detailMovie['director']; ?></label>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-9">
          <img src="<?php echo base_url().'assets/resources/'.$detailMovie['poster']; ?>" width="200" height="300">
        </div>
      </div>
    </div>
    <hr>
</body>
<script type="text/javascript">
    $('#tableMovie').DataTable();
</script>
</html>