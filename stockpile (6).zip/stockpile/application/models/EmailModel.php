<?php
	class EmailModel extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->library('email');
		}

		function sendVerificationEmail($email,$verificationText){
			try{
			$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => '', //email gmail lu
					'smtp_pass' => '', //password gmail lu
					'mailtype' => 'html',
					'charset' => 'iso-8859-1',
					'wordwrap' => TRUE
				);
			
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->from('admin@localhost', "Admin Team");
			  $this->email->to($email);  
			  $this->email->subject("Email Verification");
			  $this->email->message("Dear User,\nPlease click on below URL or paste into your browser to verify your Email Address\n\n http://localhost/stockpile/index.php/UserActions/verify/".$verificationText."\n"."\n\nThanks\nAdmin Team");
			  $this->email->send();
			 }
			 catch(Exception $e){
			 	echo "Message: ".$e->getMessage();
			 }

		}
	}

?>