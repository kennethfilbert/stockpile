<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model{
	public function __construct(){
		$this->contributorTable = 'contributors';
		$this->photoTable = 'photos';
	}

	public function getRows($params = array()){
		$this->db->select('*');
		$this->db->from($this->contributorTable);

		if(array_key_exists("conditions", $params)){
			foreach ($params['conditions'] as $key => $value) {
				$this->db->where($key, $value);
			}
		}

		if(array_key_exists("id",$params)){
			$this->db->where('contributorID', $params['id']);
			$query = $this->db->get();
			$result = $query->row_array();
		}
		else{
			if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit'],$params['start']);
            }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit']);
            }
            $query = $this->db->get();
            if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
                $result = $query->num_rows();
            }elseif(array_key_exists("returnType",$params) && $params['returnType'] == 'single'){
                $result = ($query->num_rows() > 0)?$query->row_array():FALSE;
            }else{
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
		}

		return $result;
	}

	public function get_index($index){
		$this->db->select('contributorID');
		$this->db->from('contributors');
		$this->db->where('contributorID', $index);

		if($query=$this->db->get())
		  {
		      return $query->row_array();
		  }
		  else{
		    	return false;
		  }
	}

	public function get_id(){
		$this->db->select('contributorID');
		$this->db->from('contributors');
		$query=$this->db->get();
	}

	public function get_email($email){
		$this->db->select('email');
		$this->db->from('contributors');
		$this->db->where('email', $email);

		if($query=$this->db->get())
		  {
		      return $query->row_array();
		  }
		  else{
		    	return false;
		  }
	}

	public function get_verification($code){
		$this->db->select('verificationCode');
		$this->db->from('contributors');
		$this->db->where('verificationCode', $code);

		if($query=$this->db->get())
		  {
		      return $query->row_array();
		  }
		  else{
		    	return false;
		  }
	}

 	public function email_check($email){
 
	  $this->db->select('*');
	  $this->db->from('contributors');
	  $this->db->where('email',$email);
	  $query=$this->db->get();
	 
	  if($query->num_rows()>0){
	    return false;
	  }else{
	    return true;
	  }
 
}

	public function insert($data = array()){
		/*if(!array_key_exists("created", $data)){
			$data['created'] = data("Y-m-d H:i:s");
		}
		if(!array_key_exists("modified", $data)){
			$data['modified'] = data("Y-m-d H:i:s");
		}*/

		$insert = $this->db->insert($this->contributorTable, $data);

		if($insert){
			return $this->db->insert_id();;
		}
		else{
			return false;
		}
	}

	function verifyEmailAddress($verificationCode){  
	  $sql = "update contributors set verifiedStatus='A' WHERE verificationCode=?";
	  $this->db->query($sql, array($verificationCode));
	  return $this->db->affected_rows(); 
 	}

 	public function getPictures(){
			$query = $this->db->query("SELECT * FROM photos");

			return $query->result_array();
	}

	public function getPictureID(){
		$this->db->select('photoID');
		$this->db->from('photos');
		$query=$this->db->get();

	}

	public function getPicturesByUser($id){
			$this->db->select('*');
	  		$this->db->from('photos');
	  		$this->db->where('contributorID',$id);
	  		$query=$this->db->get();
	 
		  if($query->num_rows()==0){
		    return false;
		  }else{
		    return $query->result_array();
		  }
		}

	public function getPictureOwner($id){
			$this->db->select('username');
	  		$this->db->from('contributors');
	  		$this->db->join('photos','photos.contributorID = contributors.contributorID');
	  		$this->db->where('photos.contributorID', $id);
	 	if($query=$this->db->get())
		  {
		      return $query->row_array();
		  }
		  else{
		    	return false;
		  }

		
		}

	public function getClickedPicture($id){
		$this->db->select('*');
	  	$this->db->from('photos');

	  	//$this->db->join('contributors', 'contributors.contributorID = photos.contributorID');
	  	$this->db->where('photoID', $id);
	  		
	 	if($query=$this->db->get())
		  {
		      return $query->row_array();
		  }
		  else{
		    	return false;
		  }
	}

	public function insert_photos($data = array()){
        $insert = $this->db->insert($this->photoTable,$data);
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;    
        }
	}

	public function delete_photo($id){
		
		$this->db->where('photoID', $id);
		$this->db->delete('photos');
	    
	}

	public function searcher($search_term) {
	    $this->db->select('*');
	    $this->db->from('photos');
	    $this->db->like('title', $search_term);
	    $query = $this->db->get();

	    if($query->num_rows()==0){
	    	return false;
	  	}else{
	   	 	return $query->result_array();
	  	}
	}  

	public function categorySearcher($tag) {
	    $this->db->select('*');
	    $this->db->from('photos');
	    $this->db->like('category', $tag);
	    $query = $this->db->get();

	    if($query->num_rows()==0){
	    	return false;
	  	}else{
	   	 	return $query->result_array();
	  	}
	}     
}