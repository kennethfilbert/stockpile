-- phpMyAdmin SQL Dump
-- version 4.6.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 17, 2018 at 11:29 AM
-- Server version: 5.7.13-log
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockpile`
--

-- --------------------------------------------------------

--
-- Table structure for table `contributors`
--

CREATE TABLE `contributors` (
  `contributorID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `verificationCode` varchar(255) NOT NULL,
  `verifiedStatus` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contributors`
--

INSERT INTO `contributors` (`contributorID`, `username`, `password`, `email`, `verificationCode`, `verifiedStatus`) VALUES
(1, 'asd', '7815696ecbf1c96e6894b779456d330e', 'asd@asd.com', '', ''),
(2, 'cyka', 'c2bb896dd75427c2405b887616e7a145', 'cyka@blyat.com', '4666ff11d1c9daca19c4aea4446b049c', 'A'),
(3, 'kenneth', 'cd895865e68c4793d9a906c24d50c904', 'kenneth.filbert@student.umn.ac.id', '82079c0dd528e243802a72ecf03fc8ac', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `photoID` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `photoPath` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `contributorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`photoID`, `title`, `photoPath`, `description`, `category`, `contributorID`) VALUES
(1, 'Tilted Colums', 'assets/resources/arsitektur1.jpg', 'lorem ipsum', 'architecture', 1),
(2, 'Balairung', 'assets/resources/arsitektur2.jpg', 'lorem ipsum 2', 'architecture', 1),
(3, 'Mini Niagara', 'assets/resources/nature.jpg', 'lorem ipsum 3', 'nature', 2),
(4, 'Generic', 'assets/resources/nature1.jpg', 'lorem ipsum 4', 'nature', 2),
(5, 'Mini Rainbow', 'assets/resources/nature2.jpg', 'lorem ipsum 5', 'nature', 2),
(6, 'Flame Cock', 'assets/resources/lifestyle1.jpg', 'lorem ipsum 6', 'lifestyle', 3),
(7, 'Ngebul', 'assets/resources/lifestyle2.jpg', 'lorem ipsum 7', 'lifestyle', 3),
(10, 'Fireflies', 'assets/resources/IMG_9221.JPG', 'ayy lmao 2', '', 3),
(11, 'Ray', 'assets/resources/IMG_9380.JPG', 'cute af', '', 3),
(13, 'Jellies', 'assets/resources/IMG_9311.JPG', 'spongebob', 'Animal', 3),
(14, 'Stage Play', 'assets/resources/IMG_9352.JPG', 'theatricality and deception', 'Human Interest & Lifestyle', 2);

-- --------------------------------------------------------

--
-- Table structure for table `photos_tags_rating`
--

CREATE TABLE `photos_tags_rating` (
  `photoID` int(11) NOT NULL,
  `tagID` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photos_tags_rating`
--

INSERT INTO `photos_tags_rating` (`photoID`, `tagID`, `rating`) VALUES
(1, 1, 100),
(1, 3, 1000),
(2, 2, 300);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tagID` int(11) NOT NULL,
  `tagName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`tagID`, `tagName`) VALUES
(1, 'nature'),
(2, 'architecture'),
(3, 'animal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contributors`
--
ALTER TABLE `contributors`
  ADD PRIMARY KEY (`contributorID`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`photoID`),
  ADD KEY `FK_photos_contributors` (`contributorID`);

--
-- Indexes for table `photos_tags_rating`
--
ALTER TABLE `photos_tags_rating`
  ADD KEY `FK_photos_tags_rating_photos` (`photoID`),
  ADD KEY `FK_photos_tags_rating_tags` (`tagID`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tagID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contributors`
--
ALTER TABLE `contributors`
  MODIFY `contributorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `photoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `tagID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `FK_photos_contributors` FOREIGN KEY (`contributorID`) REFERENCES `contributors` (`contributorID`);

--
-- Constraints for table `photos_tags_rating`
--
ALTER TABLE `photos_tags_rating`
  ADD CONSTRAINT `FK_photos_tags_rating_photos` FOREIGN KEY (`photoID`) REFERENCES `photos` (`photoID`),
  ADD CONSTRAINT `FK_photos_tags_rating_tags` FOREIGN KEY (`tagID`) REFERENCES `tags` (`tagID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
