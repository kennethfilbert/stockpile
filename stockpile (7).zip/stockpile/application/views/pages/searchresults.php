<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <?php
        echo $js;
        echo $css;
    ?>
<nav class="navbar navbar-gradient navbar-expand-sm fixed-top" >
    <div class="container-fluid">
        <div class="navbar-header" >
           <?php  echo '<a class="navbar-brand" style="font-size: 35px; color:white;" href="'.base_url().'">SP</a>'; ?>
        </div>

        <?php
        if(0) {
        }
        else {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<li class="nav-link white-button-no">';
                    echo 'Upload';
                echo '</li>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/logout','">';
                    echo 'Logout';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        ?>
    </div>
</nav>
</head>
<body>
<div class="container" style="margin:5%;">
    <h2>Search Results</h2>
        
        <div class="card-images">
            <?php
                    
                    if($result){
                        foreach ($result as $key => $value) {
                            echo '<div class="card" style="float:left; margin:10px; border: 0;">';
                            echo '<img class="card-img-top" src="'.base_url().$value['photoPath'].'" alt="No Image Found" style="height:300px; width: auto;">';
                            echo '<div class="card-img-overlay h-100 d-flex flex-column justify-content-end">';
                                echo '<p class="card-text">';
                                //echo 'by'.$owner['c.username'].'</p>';
                                echo '<a href="'.base_url().'index.php/PhotoActions/photoDetails/'.$value['photoID'].'">';
                                    echo "Details";
                                echo '</a>';
                           echo '</div>';
                        echo '</div>';
                    }
                    
                }
                else{
                   echo $this->session->flashdata('error_msg');
                }

            ?>

    </div>
</div>
</body>
</html>