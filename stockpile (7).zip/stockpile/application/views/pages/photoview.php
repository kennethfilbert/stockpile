<!DOCTYPE html>
<html>
<head>
	<title>Photo</title>
	<?php
		echo $js;
		echo $css;
	?>
<nav class="navbar navbar-gradient navbar-expand-sm fixed-top" >
    <div class="container-fluid">
        <div class="navbar-header" >
           <?php  echo '<a class="navbar-brand" style="font-size: 35px; color:white;" href="'.base_url().'">SP</a>'; ?>
        </div>

        <?php
        if(0) {
        }
        else {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<li class="nav-link white-button-no">';
                    echo 'Upload';
                echo '</li>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/logout','">';
                    echo 'Logout';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        ?>
    </div>
</nav>
</head>
<body>

<div class="container" style="margin:5%;">
    <h2>Photo By <?php echo $clickedPic['username']; ?></h2>

    <div class="account-info">
        <div class="card-images">
            <?php
            echo '<div class="card" style="float:left; margin:10px; border: 0;">';
                echo '<img class="card-img-top" src="'.base_url().$clickedPic['photoPath'].'" alt="No Image Found" style="height:550px; width: auto;">';
            echo '</div>';
            ?>
        </div>
    </div>
    <h2>Title</h2>
    <?php echo $clickedPic['title']; ?>
    <h2>Category</h2>
    <?php echo $clickedPic['category']?>
    <h2>Description</h2>
    <?php echo $clickedPic['description']; 
    echo '<br>';
    echo '<div class="row-3">';
        echo '<a class="row-3 btn btn-primary" href="'.base_url().$clickedPic['photoPath'].'" download>';
            echo "Download";
        echo "</a>";
    echo '</div>';

    if($this->session->userdata('isUserLoggedIn') && $this->session->userdata('userId')==$clickedPic['contributorID']){
        echo '<div class="row-3">';
            echo '<a class="row-3 btn btn-danger" name="deleteBtn" href="'.base_url().'index.php/PhotoActions/deletePhoto/'.$clickedPic['photoID'].'">';
                echo "Delete";
            echo "</a>";
         echo '</div>';
    }

    if(isset($_POST['deleteBtn'])){
        unlink(base_url().$clickedPic['photoPath']);
    }

    
    ?>
</div>
</body>
</html>