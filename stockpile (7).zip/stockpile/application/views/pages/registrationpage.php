<!DOCTYPE html>
<html>  
<head>

    <title>Register</title>
    <?php
      echo $js;
      echo $css;
    ?>
    
<nav class="navbar navbar-gradient navbar-expand-sm fixed-top" >
    <div class="container-fluid">
        <div class="navbar-header" >
           <?php  echo '<a class="navbar-brand" style="font-size: 35px; color:white;" href="'.base_url().'">SP</a>'; ?>
        </div>

        <?php
        if(!$this->session->userdata('isUserLoggedIn')) {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/login','">';
                    echo 'Login';
                echo '</a>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/registration','">';
                    echo 'Sign Up';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        else {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            if($user[$index]['verifiedStatus'] =='A'){
                echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                    echo '<a class="nav-link white-button-emp" href="'.base_url().'index.php/UserActions/upload','">';
                        echo 'Upload';
                    echo '</a>';
                echo '</li>';
            }
            else {
                echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                    echo '<li class="nav-link white-button-no">';
                        echo 'Upload';
                    echo '</li>';
                echo '</li>';
            }

            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/account','">';
                    echo $user[$index]['username'];
                echo '</a>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/logout','">';
                    echo 'Logout';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        ?>
    </div>
</nav>
</head>
<body>
<h2 style="text-align: center; margin-top: 5%;">Sign Up Here</h2>
<div class="container" style="margin-top: 2%;">
    
    <form action="" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Name" required="" value="<?php echo !empty($user['username'])?$user['username']:''; ?>">
          <?php echo form_error('name','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email" required="" value="<?php echo !empty($user['email'])?$user['email']:''; ?>">
          <?php echo form_error('email','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required="">
          <?php echo form_error('password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
          <input type="password" class="form-control" name="conf_password" placeholder="Confirm password" required="">
          <?php echo form_error('conf_password','<span class="help-block">','</span>'); ?>
        </div>
        <div class="form-group">
            <input type="submit" name="signUp" class="btn-primary" value="Submit"/>
        </div>
    </form>
    <p class="footInfo">Already have an account? <a href="<?php echo base_url(); ?>index.php/UserActions/login">Login here</a></p>              
</div>
</body>
</html>