<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Stockpile | Free Photo Stock Online</title>

<?php 
    echo $js;
    echo $css;
?>

<nav class="navbar navbar-gradient navbar-expand-sm fixed-top" >
    <div class="container-fluid">
<!--         <div class="navbar-header" >
           <?php  echo '<a class="navbar-brand" style="font-size: 35px; color:white;" href="'.base_url().'">SP</a>'; ?>
        </div> -->

        <?php
        if(!$this->session->userdata('isUserLoggedIn')) {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/login','">';
                    echo 'Login';
                echo '</a>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/registration','">';
                    echo 'Sign Up';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        else {
            //var_dump($_SESSION);
            echo '<ul class="navbar-nav ml-auto">';
            if($user[$index]['verifiedStatus'] =='A'){
                echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                    echo '<a class="nav-link white-button-emp" href="'.base_url().'index.php/UserActions/upload','">';
                        echo 'Upload';
                    echo '</a>';
                echo '</li>';
            }
            else {
                echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                    echo '<li class="nav-link white-button-no">';
                        echo 'Upload';
                    echo '</li>';
                echo '</li>';
            }

            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/account','">';
                    echo $user[$index]['username'];
                echo '</a>';
            echo '</li>';
            echo '<li class="nav-item" style="margin: 0px 10px 0px 10px">';
                echo '<a class="nav-link white-button" href="'.base_url().'index.php/UserActions/logout','">';
                    echo 'Logout';
                echo '</a>';
            echo '</li>';
            echo '</ul>';
        }
        ?>
    </div>
</nav>

</head>

<body>

<!-- hero image/text -->
<div class="hero-image">
    <div class="hero-text" style="color: white;">
        <h1 id="tagline">Stockpile</h1>
        <p>Free, high definition photos, from your contributions.</p>
        <?php 
        echo '<form class="searchbar" action="'.base_url().'index.php/UserActions/search','" style="margin:auto;max-width:100%" method="post">'; 
            echo '<input type="text" placeholder="Search.." name="searchBar">';
            echo '<button type="submit" name="searchBtn"><i class="fa fa-search"></i></button>';
        echo '</form>';
        ?>
    </div>
</div>

<div class="navbar-center-1">
    <nav class="navbar navbar-expand-sm navbar-center-2">
        <ul class="navbar navbar-nav">
            <?php
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Nature".'">Nature</a></li>';
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Sports".'">Sports</a></li>';
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Landscape".'">Landscape</a></li>';
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Architecture".'">Architecture</a></li>';
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Animals".'">Animals</a></li>';
                echo '<li class="nav-item"><a class="nav-link black-button" href="'.base_url().'index.php/UserActions/searchByCategory/'."Human Interest Lifestyle".'">Human Interest Lifestyle</a></li>';
            ?>
        </ul>
    </nav>
</div>
    <?php
/*    echo '<form class="sticky-bottom navbar bg-dark navbar-dark" action="">'; 
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Nature".'">Nature</a>';
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Sports".'">Sports</a>';
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Landscape".'">Landscape</a>';
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Architecture".'">Architecture</a>';
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Animals".'">Animals</a>';
        echo '<a class="btn nav-link" name="categoryBtn" href="'.base_url().'index.php/UserActions/searchByCategory/'."Human Interest Lifestyle".'">Human Interest & Lifestyle</a>';
    echo '</form>';*/
    ?>


</div>

<!--images-->

<div class="container-expand-md">
    <div class="row-expand-md-4">
    <?php

        foreach ($pics as $key => $value) {
            //var_dump($value['photoPath']);
             
            echo '<div class="card col-4" style="float:left; border: 0;">';
                echo '<img class="card-img-top" src="'.$value['photoPath'].'" alt="No Image Found" style="height:300px; width: auto;">';
                echo '<div class="card-img-overlay h-100 d-flex flex-column justify-content-end">';
                    echo '<p class="card-text">';
                    echo '"'.$value['title'].'"';
                    echo '<br>';
                    echo 'by '.$value['username'].'</p>';
                    echo '<a href="'.base_url().'index.php/PhotoActions/photoDetails/'.$value['photoID'].'">';
                        echo "Details";
                    echo '</a>';
                echo '</div>';
            echo '</div>';
        }

    

    ?>

    </div>
</div>
</body>
</html>