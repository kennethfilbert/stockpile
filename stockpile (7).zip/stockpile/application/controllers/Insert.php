<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class MoviePage extends CI_Controller{

		public function __construct(){
			parent::__construct();
			$this->load->model('movies');
			
		}
		public function index(){
			$data['js'] = $this->load->view('include/script.php', NULL, TRUE);
			$data['css'] = $this->load->view('include/style.php', NULL, TRUE);
			$data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
			$data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
			$data['movie'] = $this->movies->get_movie();
 			$this->load->view('pages/home.php', $data);
		}
		public function details(){
			$data['js'] = $this->load->view('include/javascript.php', NULL, TRUE);
			$data['css'] = $this->load->view('include/css.php', NULL, TRUE);
			$data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
			$data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
			$data['movie'] = $this->movies->get_movie();
			$data['title'] = $this->movies->get_title();
 			$this->load->view('include/detailMovie.php', $data);
		}
		public function insert(){
			$data['js'] = $this->load->view('include/javascript.php', NULL, TRUE);
			$data['css'] = $this->load->view('include/css.php', NULL, TRUE);
			$data['header'] = $this->load->view('pages/header.php', NULL, TRUE);
			$data['footer'] = $this->load->view('pages/footer.php', NULL, TRUE);
			$data['title'] = $this->movies->get_title();
			$data['supplier'] = $this->home_model->get_supplier();
			$data['category'] = $this->home_model->get_category();
 			$this->load->view('include/addMovie.php', $data);
		}
	}


?>
